﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SrinuTask.Models;

namespace SrinuTask.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class employeeController : ControllerBase
    {

        private readonly EmployeeDbContext _db;

        public employeeController(EmployeeDbContext db)
        {
            _db = db;
        }


        [HttpGet]

        public async Task<ActionResult<List<Employee>>> Get() {
            try
            {
                return await _db.Employees.ToListAsync();
            }
            catch (Exception ex)
            {
                throw ex;
               
            }
          
        }


        [HttpPost]

        public ActionResult addEmployee(Employee emp)
        {

            _db.Employees.Add(emp);
            _db.SaveChanges();
            return Ok("New user added");
        }


    }
}
