﻿namespace srinuMigrationProject.Models
{
    public class Employee
    {
        public int id { get; set; }
        public string? name { get; set; }
        public int age { get; set; }
    }
}
