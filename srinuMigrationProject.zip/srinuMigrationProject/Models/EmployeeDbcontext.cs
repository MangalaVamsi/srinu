﻿using Microsoft.EntityFrameworkCore;

namespace srinuMigrationProject.Models
{
    public class EmployeeDbcontext:DbContext
    {
        public EmployeeDbcontext(DbContextOptions options) : base(options)
        {

        }

        public DbSet<Employee> Employees { get; set; }
    }
}
