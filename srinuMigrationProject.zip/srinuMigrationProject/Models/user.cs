﻿namespace srinuMigrationProject.Models
{
    public class user
    {
        public int id { get; set; }
        public string username { get; set; }
    }
}
